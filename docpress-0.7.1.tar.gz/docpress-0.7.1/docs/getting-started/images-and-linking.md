# Images and linking

Link to documents with the `.md` extension.

```md
Read more about [installation](install.md).
```

You will still need to put it in the TOC. Also, remember all pages need to be in `docs/`.
